# 3. Build a sentiment classification model using: LSTM / BiLSTM / GRU (You 
# can perform model stacking(Ensemble Learning)) for Attention 
# Mechanism 
# a. Task to Perform: 
# b. Data preprocessing 
# c. Tokenization 
# d. Padding 
# e. Embedding Layer generation 
# f. Visualize: Training Accuracy, Validation Accuracy, Loss Curves, ROC 
# Curve 
# g. Kaggle Dataset: 
# i. Twitter Sentiment Analysis Dataset 
# ii. https://www.kaggle.com/datasets/kazanova/sentiment14 


# pip install pandas tensorflow scikit-learn matplotlib nltk

import pandas as pd
import re
import nltk
import matplotlib.pyplot as plt

from nltk.corpus import stopwords

from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_curve, auc

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import (
    Embedding,
    LSTM,
    Dense
)

from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences

nltk.download('stopwords')


# Load Dataset
df = pd.read_csv(
    "C:/Users/vedpa/OneDrive/Desktop/nlp pract/SentimentClassification/training.1600000.processed.noemoticon.csv",
    encoding='latin-1',
    header=None
)

# Keep Required Columns
df = df[[0, 5]]
df.columns = ['sentiment', 'text']

# Small Sample
df = df.head(5000)

# Convert Labels
df['sentiment'] = df['sentiment'].replace(4, 1)

# Stopwords
stop = set(stopwords.words('english'))

# Text Cleaning
def clean(text):
    text = text.lower()
    text = re.sub(r'[^a-z ]', '', text)
    return " ".join(
        word for word in text.split()
        if word not in stop
    )

# Apply Cleaning
df['text'] = df['text'].apply(clean)

# Tokenization
tokenizer = Tokenizer(num_words=5000)
tokenizer.fit_on_texts(df['text'])
seq = tokenizer.texts_to_sequences(df['text'])

# Padding
X = pad_sequences(seq, maxlen=50)
y = df['sentiment']

# Train Test Split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2
)

# LSTM Model
model = Sequential()

# Embedding Layer
model.add(
    Embedding(
        input_dim=5000,
        output_dim=64,
        input_length=50
    )
)

# LSTM Layer
model.add(
    LSTM(64)
)

# Output Layer
model.add(
    Dense(1, activation='sigmoid')
)

# Compile
model.compile(
    loss='binary_crossentropy',
    optimizer='adam',
    metrics=['accuracy']
)

# Train
history = model.fit(
    X_train,
    y_train,
    epochs=3,
    validation_data=(X_test, y_test)
)

# Accuracy Graph
plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title("Accuracy")
plt.legend(['Train', 'Validation'])
plt.show()

# Loss Graph
plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title("Loss")
plt.legend(['Train', 'Validation'])
plt.show()

# ROC Curve
pred = model.predict(X_test)
fpr, tpr, _ = roc_curve(y_test, pred)
roc_auc = auc(fpr, tpr)
plt.plot(fpr, tpr)
plt.title("ROC Curve")
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.show()
print("\nROC AUC Score :", round(roc_auc, 2))

# Prediction Example
sample = ["This movie is amazing"]
sample = tokenizer.texts_to_sequences(sample)
sample = pad_sequences(sample, maxlen=50)
result = model.predict(sample)
print("\nPrediction :")

if result[0][0] > 0.5:
    print("Positive Sentiment")
else:
    print("Negative Sentiment")