# pip install pandas scikit-learn nltk

import pandas as pd

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from nltk.translate.bleu_score import sentence_bleu

# Load Dataset
df = pd.read_json("C:/Users/vedpa/OneDrive/Desktop/nlp pract/Chatbot/train-v1.1.json")

# Create Small Q&A Dataset
questions = [
    "What is AI?",
    "Who is Narendra Modi?",
    "What is Python?",
    "What is machine learning?"
]

answers = [
    "AI means Artificial Intelligence",
    "Narendra Modi is the Prime Minister of India",
    "Python is a programming language",
    "Machine learning is a subset of AI"
]

qa = pd.DataFrame({
    "question": questions,
    "answer": answers
})

# TF-IDF Vectorization
tfidf = TfidfVectorizer()

X = tfidf.fit_transform(qa['question'])

# User Query
query = "Explain artificial intelligence"

# Convert Query
query_vector = tfidf.transform([query])

# Similarity Search
similarity = cosine_similarity(
    query_vector,
    X
)

# Best Match
index = similarity.argmax()

# Chatbot Response
response = qa['answer'][index]

print("\nUser Query :")
print(query)

print("\nChatbot Answer :")
print(response)

# Exact Match Score
actual = "AI means Artificial Intelligence"

exact_match = int(
    response.lower() == actual.lower()
)

print("\nExact Match Score :", exact_match)

# F1 Score
response_words = response.lower().split()

actual_words = actual.lower().split()

common = set(response_words) & set(actual_words)

precision = len(common) / len(response_words)

recall = len(common) / len(actual_words)

f1 = 2 * precision * recall / (
    precision + recall
)

print("F1 Score :", round(f1, 2))

# BLEU Score
bleu = sentence_bleu(
    [actual_words],
    response_words
)

print("BLEU Score :", round(bleu, 2))