# 4. Develop a Named Entity Recognition system  
# a.  Tasks:  
# Use NLTK or Spacy for NER recognition  
# Run it across an wikipedia data or an essay 
# b. Extract: Person Names, Locations, Organizations, Dates, Monetary 
# Value 

# pip install spacy
# Download Model
# python -m spacy download en_core_web_sm

import spacy

# Load SpaCy Model
nlp = spacy.load("en_core_web_sm")

# Wikipedia / Essay Text
text = """
Narendra Modi visited Mumbai on 15 August 2024.
Microsoft invested 5 million dollars in India.
Elon Musk met officials in New Delhi.
"""

# Process Text
doc = nlp(text)

print("\n===== Named Entity Recognition =====\n")

# Extract Entities
for ent in doc.ents:

    print(
        ent.text,
        "->",
        ent.label_
    )

# Entity Meaning
print("\n===== Entity Types =====\n")

print("PERSON -> Person Names")
print("GPE    -> Locations")
print("ORG    -> Organizations")
print("DATE   -> Dates")
print("MONEY  -> Monetary Values")