# 8. Create an SMS/Email Spam Detection system which consists of any one of the 
# following algorithms: 
# a. Naive Bayes 
# b. SVM 
# c. Random Forest 
# d. Ensemble Voting Classifier 
# Tasks: Handle imbalanced dataset, Feature selection, Hyperparameter tuning, 
# Comparative performance analysis 
# Note: Before implementing your model, you must perform Count Vectorizer, TF
# IDF & Word Embeddings operations in the code. 
# Kaggle Dataset: 
# SMS Spam Collection Dataset  
# https://www.kaggle.com/datasets/uciml/sms-spam-collection-dataset 
# pip install pandas nltk scikit-learn imbalanced-learn

import pandas as pd
import re
import nltk

from nltk.corpus import stopwords

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import (
    CountVectorizer,
    TfidfVectorizer
)

from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, classification_report
from imblearn.over_sampling import RandomOverSampler
nltk.download('stopwords')

# Load Dataset
df = pd.read_csv("spam.csv", encoding='latin-1')

# Keep Required Columns
df = df[['v1', 'v2']]
df.columns = ['label', 'message']

# Convert Labels
df['label'] = df['label'].map({
    'ham': 0,
    'spam': 1
})

# Stopwords
stop = set(stopwords.words('english'))

# Cleaning Function
def clean(text):

    text = text.lower()

    text = re.sub(r'[^a-z ]', '', text)

    return " ".join(
        word for word in text.split()
        if word not in stop
    )

# Clean Messages
df['message'] = df['message'].apply(clean)

# Count Vectorizer
cv = CountVectorizer(max_features=3000)
X_count = cv.fit_transform(df['message'])

#  TF-IDF 
tfidf = TfidfVectorizer(max_features=3000)
X = tfidf.fit_transform(df['message'])
y = df['label']

# Handle Imbalanced Dataset
ros = RandomOverSampler()
X, y = ros.fit_resample(X, y)

# Train Test Split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2
)

# SVM Model
model = SVC(kernel='linear')

# Hyperparameter Tuning
# kernel = linear

model.fit(X_train, y_train)

# Prediction
pred = model.predict(X_test)

# Accuracy
acc = accuracy_score(y_test, pred)
print("Accuracy :", round(acc * 100, 2), "%")

# Report
print("\nClassification Report\n")
print(classification_report(y_test, pred))

# Comparative Performance Analysis
print("\nOperations Used:")
print("1. Count Vectorizer")
print("2. TF-IDF")
print("3. SVM Classifier")
print("4. Oversampling for Imbalanced Data")

# Predict New Message
#Urgent! Your bank account has been suspended
#Please send me the notes after class
sample = ["Congratulations! You won a free iPhone"]
sample = tfidf.transform(sample)
result = model.predict(sample)
print("\nPrediction :")
if result[0] == 1:
    print("SPAM MESSAGE")
else:
    print("HAM MESSAGE")