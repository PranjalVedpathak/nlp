# 6. Build a Neural Machine Translation system for English-to-Hindi or 
# Hindi-to- English translation. 
# a. Tasks:  
# b. Use Bigrams to map translations and Generate translation samples and 
# analyze semantic correctness. 
# c.  
# d. Kaggle Dataset: 
# i. 
# English-Hindi Parallel Corpus 
# 1. https://www.kaggle.com/datasets/aiswaryaramac
# handran/hindi-english-parallel- corpus 


# pip install pandas nltk
#C:/Users/vedpa/OneDrive/Desktop/nlp pract/Translation/hindi_english_parallel.csv
# pip install pandas nltk

import pandas as pd
from nltk.util import bigrams

# Load Dataset
df = pd.read_csv("C:/Users/vedpa/OneDrive/Desktop/nlp pract/Translation/hindi_english_parallel.csv")

# Small Sample
df = df.head(1000)

# Dictionary for Translation
mapping = {}

# Create Word Mapping
for eng, hin in zip(df['english'], df['hindi']):
    eng_words = str(eng).lower().split()
    hin_words = str(hin).split()
    for ew, hw in zip(eng_words, hin_words):
        # Store first correct mapping only
        if ew not in mapping:
            mapping[ew] = hw

# Translation Function
def translate(sentence):
    words = sentence.lower().split()
    translated = []
    for word in words:
        translated.append(
            mapping.get(word, word)
        )

    return " ".join(translated)

# Translation Sample
sample = "this is cat"
result = translate(sample)
print("English :", sample)
print("Hindi :", result)

# Bigram Generation
print("\nBigrams\n")
print(list(bigrams(sample.split())))

# Semantic Correctness
print("\nSemantic Analysis")
print("Simple word-to-word translation using bigram mapping")